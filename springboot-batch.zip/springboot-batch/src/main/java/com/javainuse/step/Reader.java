package com.javainuse.step;

import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;

import com.elamp.model.InputRequest;
import com.elamp.util.CSVUtils;

public class Reader implements ItemReader<String> {

	List<String> line= null;

	private int count = 0;
	
//	String[] data;*/
	
	//private String[] phoneNumber = { "7012812388"};

	//private int count = 0;
	
	
	@SuppressWarnings("unchecked")
	@Override
	public String read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		
		
	/*	
		if (count < phoneNumber.length) {
			return phoneNumber[count++];
		} else {
			count = 0;
		}*/
		
		
		line= CSVUtils.getCsvData();
		
		
		 System.out.println("line size::"+line.size());
		 for(int i=0;i<line.size();i++) {
			System.out.println("line data::"+line.get(i)); 
			
		 }
		 
		 if (count < line.size()) {
				return line.get(count++);
			} else {
				count = 0;
			}
			return null;
	}

}