package com.elamp.model;

public class Employee {

}
